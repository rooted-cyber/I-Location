banner() {
	random
	figlet I Location
	echo
	printf "\033[1;93m[\033[1;77m::\033[1;93m]	\033[1;92mCreate by : \033[1;97mhttps://github.com/thewhiteh4t	\033[1;93m[\033[1;77m::\033[1;93m]"
	printf "\n\033[1;93m[\033[1;77m::\033[1;93m]	\033[1;92mEdited by : \033[1;97mhttps://github.com/rooted-cyber	\033[1;93m[\033[1;77m::\033[1;93m]\n"
	printf "\n\033[1;93m	[\033[1;97m::\033[1;93m]	\033[1;96mThis Tool Version : \033[1;97m1.2.4	\033[1;93m[\033[1;77m::\033[1;93m]\n"
	
	}
	banner